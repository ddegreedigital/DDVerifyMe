'use client';
import { useState, useEffect } from 'react';
import { Upload, Shield, QrCode, Clock, CheckCircle, XCircle, AlertTriangle, Plus, Eye, ExternalLink } from 'lucide-react';
import Link from 'next/link';
import { api } from '@/services/api';
import { Credential, CredentialStatus } from '@/types';
import UploadCredentialModal from '@/components/UploadCredentialModal';
import CredentialCard from '@/components/CredentialCard';
import StatsBar from '@/components/StatsBar';

export default function GraduateDashboard() {
  const [credentials, setCredentials] = useState<Credential[]>([]);
  const [loading, setLoading] = useState(true);
  const [showUpload, setShowUpload] = useState(false);

  useEffect(() => {
    fetchCredentials();
  }, []);

  async function fetchCredentials() {
    try {
      const data = await api.get('/graduate/credentials');
      setCredentials(data);
    } finally {
      setLoading(false);
    }
  }

  const stats = {
    total: credentials.length,
    verified: credentials.filter(c => c.status === CredentialStatus.VERIFIED).length,
    pending: credentials.filter(c => c.status === CredentialStatus.PENDING || c.status === CredentialStatus.UNDER_REVIEW).length,
    blockchain: credentials.filter(c => c.blockchain_tx_hash).length,
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      {/* Header */}
      <div className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800">
        <div className="max-w-5xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">My Credentials</h1>
              <p className="text-sm text-gray-500 mt-1">Your verified academic and professional portfolio</p>
            </div>
            <button
              onClick={() => setShowUpload(true)}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
            >
              <Plus size={16} />
              Add Credential
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Total', value: stats.total, icon: Shield, color: 'text-gray-600' },
            { label: 'Verified', value: stats.verified, icon: CheckCircle, color: 'text-green-600' },
            { label: 'Pending', value: stats.pending, icon: Clock, color: 'text-amber-600' },
            { label: 'On Blockchain', value: stats.blockchain, icon: ExternalLink, color: 'text-blue-600' },
          ].map(({ label, value, icon: Icon, color }) => (
            <div key={label} className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-4">
              <div className="flex items-center gap-2 mb-2">
                <Icon size={16} className={color} />
                <span className="text-xs text-gray-500">{label}</span>
              </div>
              <p className="text-2xl font-semibold text-gray-900 dark:text-white">{value}</p>
            </div>
          ))}
        </div>

        {/* Credentials List */}
        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-6 animate-pulse">
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/3 mb-3" />
                <div className="h-3 bg-gray-100 dark:bg-gray-800 rounded w-1/2" />
              </div>
            ))}
          </div>
        ) : credentials.length === 0 ? (
          <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-16 text-center">
            <Shield size={40} className="mx-auto text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300 mb-2">No credentials yet</h3>
            <p className="text-sm text-gray-500 mb-6">Upload your first certificate to get started</p>
            <button
              onClick={() => setShowUpload(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg text-sm font-medium"
            >
              Upload Certificate
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {credentials.map(credential => (
              <CredentialCard
                key={credential.id}
                credential={credential}
                onRefresh={fetchCredentials}
              />
            ))}
          </div>
        )}
      </div>

      {showUpload && (
        <UploadCredentialModal
          onClose={() => setShowUpload(false)}
          onSuccess={() => { setShowUpload(false); fetchCredentials(); }}
        />
      )}
    </div>
  );
}
