'use client';
import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import { CheckCircle, XCircle, Shield, Link as LinkIcon, Calendar, Building, Award, AlertTriangle } from 'lucide-react';

interface VerificationResult {
  verified: boolean;
  credential: {
    title: string;
    type: string;
    issued_date: string;
    status: string;
    graduate_name: string;
    institution_name: string;
    blockchain_anchored: boolean;
    blockchain_tx: string;
    verified_at: string;
  };
}

export default function PublicVerifyPage() {
  const params = useParams();
  const qrCodeId = params?.id as string;

  const [result, setResult] = useState<VerificationResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (qrCodeId) verify();
  }, [qrCodeId]);

  async function verify() {
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/verify/${qrCodeId}`);
      if (!res.ok) throw new Error('Credential not found');
      const data = await res.json();
      setResult(data);
    } catch (e) {
      setError('This credential could not be found or is no longer public.');
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-600 dark:text-gray-400">Verifying credential...</p>
        </div>
      </div>
    );
  }

  if (error || !result) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex items-center justify-center p-4">
        <div className="bg-white dark:bg-gray-900 rounded-2xl border border-red-100 dark:border-red-900 p-8 max-w-md w-full text-center">
          <XCircle size={48} className="mx-auto text-red-500 mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Not Found</h2>
          <p className="text-gray-500 text-sm">{error}</p>
        </div>
      </div>
    );
  }

  const { credential } = result;
  const isVerified = result.verified;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex items-center justify-center p-4">
      <div className="max-w-lg w-full space-y-4">
        {/* Main status card */}
        <div className={`rounded-2xl border-2 p-8 text-center ${
          isVerified
            ? 'bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800'
            : 'bg-red-50 dark:bg-red-950 border-red-200 dark:border-red-800'
        }`}>
          {isVerified ? (
            <CheckCircle size={56} className="mx-auto text-green-600 dark:text-green-400 mb-4" />
          ) : (
            <AlertTriangle size={56} className="mx-auto text-red-600 dark:text-red-400 mb-4" />
          )}

          <div className={`inline-block px-4 py-1 rounded-full text-sm font-medium mb-4 ${
            isVerified
              ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200'
              : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
          }`}>
            {isVerified ? 'VERIFIED & AUTHENTIC' : 'NOT VERIFIED'}
          </div>

          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-1">{credential.title}</h1>
          <p className="text-gray-600 dark:text-gray-400">{credential.graduate_name}</p>
        </div>

        {/* Details card */}
        <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-100 dark:border-gray-800">
            <h2 className="text-sm font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wider">Credential Details</h2>
          </div>
          <div className="divide-y divide-gray-100 dark:divide-gray-800">
            {[
              { icon: Building, label: 'Institution', value: credential.institution_name },
              { icon: Award, label: 'Type', value: credential.type?.replace(/_/g, ' ').toUpperCase() },
              { icon: Calendar, label: 'Issued', value: credential.issued_date ? new Date(credential.issued_date).toLocaleDateString('en-NG', { year: 'numeric', month: 'long' }) : 'N/A' },
              { icon: Shield, label: 'Verified on', value: new Date(credential.verified_at).toLocaleDateString('en-NG', { year: 'numeric', month: 'long', day: 'numeric' }) },
            ].map(({ icon: Icon, label, value }) => (
              <div key={label} className="flex items-center gap-4 px-6 py-4">
                <div className="w-8 h-8 rounded-lg bg-blue-50 dark:bg-blue-950 flex items-center justify-center flex-shrink-0">
                  <Icon size={16} className="text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <p className="text-xs text-gray-500">{label}</p>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">{value}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Blockchain card */}
        {credential.blockchain_anchored && (
          <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-8 h-8 rounded-lg bg-purple-50 dark:bg-purple-950 flex items-center justify-center">
                <LinkIcon size={16} className="text-purple-600 dark:text-purple-400" />
              </div>
              <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300">Blockchain Anchored</h3>
            </div>
            <p className="text-xs text-gray-500 mb-2">This credential is permanently recorded on the Polygon blockchain</p>
            <a
              href={`https://polygonscan.com/tx/${credential.blockchain_tx}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-blue-600 dark:text-blue-400 font-mono break-all hover:underline"
            >
              {credential.blockchain_tx}
            </a>
          </div>
        )}

        {/* Footer */}
        <p className="text-center text-xs text-gray-400">
          Verified by{' '}
          <a href="https://ddverifyme.com" className="text-blue-600 dark:text-blue-400 font-medium">DDVerifyMe</a>
          {' '}— Africa&apos;s trusted credential platform
        </p>
      </div>
    </div>
  );
}
