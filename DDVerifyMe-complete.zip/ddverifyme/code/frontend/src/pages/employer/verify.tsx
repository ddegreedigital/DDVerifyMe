'use client';
import { useState } from 'react';
import { QrCode, Upload, Search, CheckCircle, XCircle, AlertTriangle, Download, Clock } from 'lucide-react';
import { api } from '@/services/api';

interface VerificationResult {
  verified: boolean;
  credential: {
    title: string;
    type: string;
    graduate_name: string;
    institution_name: string;
    issued_date: string;
    blockchain_anchored: boolean;
    verified_at: string;
    fraud_score?: number;
  };
}

type TabType = 'quick' | 'batch' | 'history';

export default function EmployerVerifyPage() {
  const [activeTab, setActiveTab] = useState<TabType>('quick');
  const [qrInput, setQrInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<VerificationResult | null>(null);
  const [error, setError] = useState('');
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [batchResult, setBatchResult] = useState<any>(null);

  async function verifyCredential() {
    if (!qrInput.trim()) return;
    setLoading(true);
    setResult(null);
    setError('');

    try {
      // Extract QR code ID from URL or use directly
      const qrId = qrInput.includes('/verify/')
        ? qrInput.split('/verify/').pop()
        : qrInput.trim();

      const data = await api.post('/employer/verify', {
        qr_code_id: qrId,
        purpose: 'employment_screening',
      });
      setResult(data);
    } catch {
      setError('Credential not found. Check the URL or QR code and try again.');
    } finally {
      setLoading(false);
    }
  }

  async function submitBatch() {
    if (!csvFile) return;
    setLoading(true);
    const form = new FormData();
    form.append('file', csvFile);
    try {
      const data = await api.postForm('/employer/verify/batch', form);
      setBatchResult(data);
    } finally {
      setLoading(false);
    }
  }

  const fraudRiskColor = (score: number) => {
    if (score < 30) return 'text-green-600';
    if (score < 65) return 'text-amber-600';
    return 'text-red-600';
  };
  const fraudRiskLabel = (score: number) => {
    if (score < 30) return 'Low risk';
    if (score < 65) return 'Medium risk';
    return 'High risk — review manually';
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      <div className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Verify Credentials</h1>
          <p className="text-sm text-gray-500 mt-1">Instant, AI-powered verification with blockchain proof</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Tabs */}
        <div className="flex gap-1 bg-gray-100 dark:bg-gray-800 p-1 rounded-xl mb-8 w-fit">
          {([
            { id: 'quick', label: 'Quick Verify', icon: Search },
            { id: 'batch', label: 'Batch CSV', icon: Upload },
            { id: 'history', label: 'History', icon: Clock },
          ] as { id: TabType; label: string; icon: any }[]).map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setActiveTab(id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === id
                  ? 'bg-white dark:bg-gray-900 text-gray-900 dark:text-white shadow-sm'
                  : 'text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
              }`}
            >
              <Icon size={15} />
              {label}
            </button>
          ))}
        </div>

        {/* Quick Verify */}
        {activeTab === 'quick' && (
          <div className="space-y-6">
            <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-6">
              <h2 className="text-base font-semibold mb-4 text-gray-900 dark:text-white">Paste QR link or credential URL</h2>
              <div className="flex gap-3">
                <input
                  type="text"
                  value={qrInput}
                  onChange={e => setQrInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && verifyCredential()}
                  placeholder="https://ddverifyme.com/verify/abc123 or just abc123"
                  className="flex-1 border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 rounded-lg px-4 py-2.5 text-sm text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button
                  onClick={verifyCredential}
                  disabled={loading || !qrInput.trim()}
                  className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white px-6 py-2.5 rounded-lg text-sm font-medium transition-colors"
                >
                  {loading ? 'Checking...' : 'Verify'}
                </button>
              </div>

              <div className="mt-4 flex items-center gap-3 text-xs text-gray-400">
                <QrCode size={14} />
                <span>Or scan a QR code with your device camera — coming soon in the mobile app</span>
              </div>
            </div>

            {/* Error */}
            {error && (
              <div className="bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-xl p-4 flex gap-3">
                <XCircle size={18} className="text-red-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-red-700 dark:text-red-300">{error}</p>
              </div>
            )}

            {/* Result */}
            {result && (
              <div className={`rounded-2xl border-2 overflow-hidden ${
                result.verified
                  ? 'border-green-200 dark:border-green-800'
                  : 'border-red-200 dark:border-red-800'
              }`}>
                {/* Status banner */}
                <div className={`px-6 py-4 flex items-center gap-3 ${
                  result.verified
                    ? 'bg-green-600'
                    : 'bg-red-600'
                }`}>
                  {result.verified
                    ? <CheckCircle size={22} className="text-white" />
                    : <XCircle size={22} className="text-white" />
                  }
                  <div>
                    <p className="text-white font-semibold">
                      {result.verified ? 'Credential Verified' : 'Verification Failed'}
                    </p>
                    <p className="text-white/80 text-xs">
                      {result.verified
                        ? 'This credential is authentic and has been verified by the issuing institution'
                        : 'This credential could not be verified'}
                    </p>
                  </div>
                </div>

                {/* Details */}
                <div className="bg-white dark:bg-gray-900 p-6 grid grid-cols-2 gap-4">
                  {[
                    { label: 'Graduate Name', value: result.credential.graduate_name },
                    { label: 'Credential', value: result.credential.title },
                    { label: 'Institution', value: result.credential.institution_name },
                    { label: 'Issued', value: result.credential.issued_date ? new Date(result.credential.issued_date).toLocaleDateString() : 'N/A' },
                    { label: 'Blockchain Proof', value: result.credential.blockchain_anchored ? 'Yes — anchored on Polygon' : 'Not anchored' },
                    { label: 'Verified On', value: new Date(result.credential.verified_at).toLocaleDateString() },
                  ].map(({ label, value }) => (
                    <div key={label}>
                      <p className="text-xs text-gray-500 mb-1">{label}</p>
                      <p className="text-sm font-medium text-gray-900 dark:text-white">{value}</p>
                    </div>
                  ))}

                  {result.credential.fraud_score !== undefined && (
                    <div className="col-span-2 pt-4 border-t border-gray-100 dark:border-gray-800">
                      <p className="text-xs text-gray-500 mb-1">AI Fraud Risk Score</p>
                      <div className="flex items-center gap-3">
                        <div className="flex-1 h-2 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              result.credential.fraud_score < 30 ? 'bg-green-500' :
                              result.credential.fraud_score < 65 ? 'bg-amber-500' : 'bg-red-500'
                            }`}
                            style={{ width: `${result.credential.fraud_score}%` }}
                          />
                        </div>
                        <span className={`text-xs font-medium ${fraudRiskColor(result.credential.fraud_score)}`}>
                          {result.credential.fraud_score}/100 — {fraudRiskLabel(result.credential.fraud_score)}
                        </span>
                      </div>
                    </div>
                  )}
                </div>

                <div className="bg-gray-50 dark:bg-gray-800 px-6 py-3 flex justify-end">
                  <button className="flex items-center gap-2 text-sm text-blue-600 dark:text-blue-400 font-medium hover:underline">
                    <Download size={14} />
                    Download PDF Report
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Batch CSV */}
        {activeTab === 'batch' && (
          <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-8">
            <h2 className="text-base font-semibold mb-2 text-gray-900 dark:text-white">Batch Verification</h2>
            <p className="text-sm text-gray-500 mb-6">Upload a CSV with a column of credential URLs or QR code IDs</p>

            <div
              className="border-2 border-dashed border-gray-200 dark:border-gray-700 rounded-xl p-12 text-center cursor-pointer hover:border-blue-400 transition-colors"
              onClick={() => document.getElementById('csv-input')?.click()}
            >
              <Upload size={28} className="mx-auto text-gray-300 mb-3" />
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {csvFile ? csvFile.name : 'Click to upload CSV file'}
              </p>
              <p className="text-xs text-gray-400 mt-1">Max 5MB — one credential URL per row</p>
              <input
                id="csv-input"
                type="file"
                accept=".csv"
                className="hidden"
                onChange={e => setCsvFile(e.target.files?.[0] || null)}
              />
            </div>

            {csvFile && (
              <button
                onClick={submitBatch}
                disabled={loading}
                className="mt-4 w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl text-sm font-medium"
              >
                {loading ? 'Processing...' : `Verify ${csvFile.name}`}
              </button>
            )}

            {batchResult && (
              <div className="mt-6 p-4 bg-green-50 dark:bg-green-950 rounded-xl">
                <p className="text-sm font-medium text-green-800 dark:text-green-200">
                  Batch complete: {batchResult.verified} verified, {batchResult.failed} failed
                </p>
                <button className="mt-2 text-sm text-blue-600 underline">Download report</button>
              </div>
            )}
          </div>
        )}

        {/* History placeholder */}
        {activeTab === 'history' && (
          <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-8 text-center">
            <Clock size={32} className="mx-auto text-gray-300 mb-3" />
            <p className="text-gray-500 text-sm">Verification history and audit trail will appear here</p>
          </div>
        )}
      </div>
    </div>
  );
}
