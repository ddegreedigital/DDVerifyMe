// services/api.ts
const BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api/v1';

function getToken(): string | null {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem('ddv_token');
}

async function request<T>(
  method: string,
  path: string,
  body?: any,
  isForm = false,
): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = {};
  if (token) headers['Authorization'] = `Bearer ${token}`;
  if (!isForm) headers['Content-Type'] = 'application/json';

  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers,
    body: isForm ? body : body ? JSON.stringify(body) : undefined,
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({ message: 'Request failed' }));
    throw new Error(err.message || 'Request failed');
  }

  return res.json();
}

export const api = {
  get: <T>(path: string) => request<T>('GET', path),
  post: <T>(path: string, body?: any) => request<T>('POST', path, body),
  put: <T>(path: string, body?: any) => request<T>('PUT', path, body),
  delete: <T>(path: string) => request<T>('DELETE', path),
  postForm: <T>(path: string, form: FormData) => request<T>('POST', path, form, true),
};

// types/index.ts
export enum CredentialStatus {
  PENDING = 'pending',
  UNDER_REVIEW = 'under_review',
  VERIFIED = 'verified',
  REJECTED = 'rejected',
  EXPIRED = 'expired',
}

export enum CredentialType {
  DEGREE = 'degree',
  HND = 'hnd',
  OND = 'ond',
  WAEC = 'waec',
  NECO = 'neco',
  NABTEB = 'nabteb',
  PROFESSIONAL = 'professional',
  VOCATIONAL = 'vocational',
  BOOTCAMP = 'bootcamp',
  OTHER = 'other',
}

export interface Credential {
  id: string;
  type: CredentialType;
  title: string;
  field_of_study?: string;
  grade?: string;
  issued_date?: string;
  expiry_date?: string;
  certificate_number?: string;
  status: CredentialStatus;
  blockchain_tx_hash?: string;
  qr_code_id?: string;
  share_url?: string;
  fraud_score?: number;
  is_public: boolean;
  view_count: number;
  institution?: {
    id: string;
    name: string;
    country: string;
  };
  created_at: string;
  updated_at: string;
}

export interface User {
  id: string;
  email: string;
  first_name: string;
  last_name: string;
  role: 'graduate' | 'employer' | 'institution' | 'admin';
  phone?: string;
  avatar_url?: string;
  created_at: string;
}

export interface Institution {
  id: string;
  name: string;
  type: 'university' | 'polytechnic' | 'college' | 'professional_body' | 'vocational';
  country: string;
  city: string;
  verified: boolean;
  logo_url?: string;
  website?: string;
}
