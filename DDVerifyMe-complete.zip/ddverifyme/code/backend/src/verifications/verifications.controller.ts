import {
  Controller, Get, Post, Body, Param, Query,
  UseGuards, Request, UploadedFile, UseInterceptors,
  ParseFilePipe, MaxFileSizeValidator, FileTypeValidator,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiParam } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RolesGuard } from '../auth/roles.guard';
import { Roles } from '../auth/roles.decorator';
import { CredentialsService } from '../credentials/credentials.service';
import { VerificationsService } from './verifications.service';

@ApiTags('verifications')
@Controller('api/v1')
export class VerificationsController {
  constructor(
    private credentialsService: CredentialsService,
    private verificationsService: VerificationsService,
  ) {}

  /**
   * Public endpoint — QR scan or share link verification
   * No auth required
   */
  @Get('verify/:qrCodeId')
  @ApiOperation({ summary: 'Public credential verification via QR code or share link' })
  @ApiParam({ name: 'qrCodeId', description: 'QR code ID from credential' })
  async publicVerify(@Param('qrCodeId') qrCodeId: string) {
    return this.credentialsService.getPublicVerificationResult(qrCodeId);
  }

  /**
   * Employer: verify a credential (authenticated)
   */
  @Post('employer/verify')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('employer')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Employer verifies a credential and logs the check' })
  async employerVerify(
    @Request() req,
    @Body() body: { qr_code_id: string; purpose?: string },
  ) {
    const result = await this.credentialsService.getPublicVerificationResult(body.qr_code_id);

    // Log verification for audit trail
    await this.verificationsService.logEmployerVerification({
      employer_id: req.user.employer_id,
      qr_code_id: body.qr_code_id,
      purpose: body.purpose,
      result: result.verified,
    });

    return result;
  }

  /**
   * Employer: batch verify via CSV
   */
  @Post('employer/verify/batch')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('employer')
  @ApiBearerAuth()
  @UseInterceptors(FileInterceptor('file'))
  @ApiOperation({ summary: 'Batch verify credentials from CSV upload' })
  async batchVerify(
    @Request() req,
    @UploadedFile(new ParseFilePipe({
      validators: [
        new MaxFileSizeValidator({ maxSize: 5 * 1024 * 1024 }), // 5MB
        new FileTypeValidator({ fileType: 'text/csv' }),
      ],
    })) file: Express.Multer.File,
  ) {
    return this.verificationsService.processBatchCsv(req.user.employer_id, file.buffer);
  }

  /**
   * Employer: get verification history
   */
  @Get('employer/verifications')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('employer')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get employer verification history with audit trail' })
  async getVerificationHistory(
    @Request() req,
    @Query('page') page = 1,
    @Query('limit') limit = 20,
  ) {
    return this.verificationsService.getEmployerHistory(req.user.employer_id, +page, +limit);
  }

  /**
   * Graduate: request institution to verify credential
   */
  @Post('graduate/credentials/:id/request-verification')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('graduate')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Graduate requests institution to verify a credential' })
  async requestVerification(@Request() req, @Param('id') credentialId: string) {
    return this.credentialsService.requestVerification(credentialId, req.user.id);
  }

  /**
   * Institution: approve or reject a verification
   */
  @Post('institution/verifications/:id/respond')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('institution')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Institution approves or rejects a credential verification' })
  async respondToVerification(
    @Request() req,
    @Param('id') credentialId: string,
    @Body() body: { approved: boolean; notes?: string },
  ) {
    return this.credentialsService.verifyByInstitution(
      credentialId,
      req.user.institution_id,
      body.approved,
      body.notes,
    );
  }

  /**
   * Institution: pending verification requests queue
   */
  @Get('institution/verifications/pending')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('institution')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get all pending verification requests for institution' })
  async getPendingVerifications(
    @Request() req,
    @Query('page') page = 1,
    @Query('limit') limit = 20,
  ) {
    return this.verificationsService.getPendingForInstitution(req.user.institution_id, +page, +limit);
  }
}
