import { Injectable, NotFoundException, ForbiddenException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { v4 as uuidv4 } from 'uuid';
import { Credential, CredentialStatus, CredentialType } from './credential.entity';
import { BlockchainService } from '../blockchain/blockchain.service';
import { AiService } from '../ai/ai.service';
import { StorageService } from '../storage/storage.service';
import { NotificationsService } from '../notifications/notifications.service';

export interface CreateCredentialDto {
  type: CredentialType;
  title: string;
  field_of_study?: string;
  grade?: string;
  issued_date?: Date;
  expiry_date?: Date;
  certificate_number?: string;
  institution_id?: string;
}

@Injectable()
export class CredentialsService {
  constructor(
    @InjectRepository(Credential)
    private credentialRepo: Repository<Credential>,
    private blockchainService: BlockchainService,
    private aiService: AiService,
    private storageService: StorageService,
    private notificationsService: NotificationsService,
  ) {}

  async create(
    graduateId: string,
    dto: CreateCredentialDto,
    file: Express.Multer.File,
  ): Promise<Credential> {
    // Upload document to S3
    const documentKey = `credentials/${graduateId}/${uuidv4()}/${file.originalname}`;
    const documentUrl = await this.storageService.upload(documentKey, file.buffer, file.mimetype);

    // Run AI fraud pre-screening
    const fraudAnalysis = await this.aiService.analyzeDocument(file.buffer, dto.type);

    const qrCodeId = uuidv4().replace(/-/g, '').substring(0, 12);

    const credential = this.credentialRepo.create({
      ...dto,
      graduate_id: graduateId,
      document_url: documentUrl,
      fraud_score: fraudAnalysis.score,
      fraud_flags: fraudAnalysis.flags,
      qr_code_id: qrCodeId,
      share_url: `${process.env.APP_URL}/verify/${qrCodeId}`,
      status: CredentialStatus.PENDING,
    });

    const saved = await this.credentialRepo.save(credential);

    // Notify institution if linked
    if (dto.institution_id) {
      await this.notificationsService.notifyInstitution(dto.institution_id, {
        type: 'verification_request',
        credential_id: saved.id,
        message: `New verification request for ${dto.title}`,
      });
    }

    return saved;
  }

  async findByGraduate(graduateId: string): Promise<Credential[]> {
    return this.credentialRepo.find({
      where: { graduate_id: graduateId },
      relations: ['institution'],
      order: { created_at: 'DESC' },
    });
  }

  async findByQrCode(qrCodeId: string): Promise<Credential> {
    const credential = await this.credentialRepo.findOne({
      where: { qr_code_id: qrCodeId, is_public: true },
      relations: ['graduate', 'institution'],
    });

    if (!credential) throw new NotFoundException('Credential not found or is private');

    // Increment view count
    await this.credentialRepo.increment({ id: credential.id }, 'view_count', 1);
    return credential;
  }

  async requestVerification(credentialId: string, graduateId: string): Promise<Credential> {
    const credential = await this.credentialRepo.findOne({
      where: { id: credentialId, graduate_id: graduateId },
    });

    if (!credential) throw new NotFoundException('Credential not found');
    if (!credential.institution_id) throw new BadRequestException('No institution linked to this credential');
    if (credential.status === CredentialStatus.VERIFIED) {
      throw new BadRequestException('Credential is already verified');
    }

    credential.status = CredentialStatus.UNDER_REVIEW;
    const updated = await this.credentialRepo.save(credential);

    await this.notificationsService.notifyInstitution(credential.institution_id, {
      type: 'verification_request',
      credential_id: credentialId,
      message: `Verification requested for ${credential.title}`,
    });

    return updated;
  }

  async verifyByInstitution(
    credentialId: string,
    institutionId: string,
    approved: boolean,
    notes?: string,
  ): Promise<Credential> {
    const credential = await this.credentialRepo.findOne({
      where: { id: credentialId, institution_id: institutionId },
    });

    if (!credential) throw new NotFoundException('Credential not found');

    if (approved) {
      credential.status = CredentialStatus.VERIFIED;

      // Anchor to blockchain
      try {
        const { txHash, credentialId: blockchainId } =
          await this.blockchainService.anchorCredential({
            credentialId: credential.id,
            graduateId: credential.graduate_id,
            institutionId: credential.institution_id,
            title: credential.title,
            issuedDate: credential.issued_date?.toISOString(),
          });

        credential.blockchain_tx_hash = txHash;
        credential.blockchain_credential_id = blockchainId;
      } catch (err) {
        console.error('Blockchain anchoring failed, continuing without:', err.message);
      }
    } else {
      credential.status = CredentialStatus.REJECTED;
    }

    const updated = await this.credentialRepo.save(credential);

    // Notify graduate
    await this.notificationsService.notifyGraduate(credential.graduate_id, {
      type: approved ? 'credential_verified' : 'credential_rejected',
      credential_id: credentialId,
      message: approved
        ? `Your ${credential.title} has been verified!`
        : `Your ${credential.title} verification was not approved. ${notes || ''}`,
    });

    return updated;
  }

  async getPublicVerificationResult(qrCodeId: string) {
    const credential = await this.findByQrCode(qrCodeId);

    return {
      verified: credential.status === CredentialStatus.VERIFIED,
      credential: {
        title: credential.title,
        type: credential.type,
        issued_date: credential.issued_date,
        status: credential.status,
        graduate_name: credential.graduate
          ? `${credential.graduate.first_name} ${credential.graduate.last_name}`
          : null,
        institution_name: credential.institution?.name,
        blockchain_anchored: !!credential.blockchain_tx_hash,
        blockchain_tx: credential.blockchain_tx_hash,
        verified_at: credential.updated_at,
      },
    };
  }
}
