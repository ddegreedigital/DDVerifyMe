// credentials/credential.entity.ts
import {
  Entity, PrimaryGeneratedColumn, Column, CreateDateColumn,
  UpdateDateColumn, ManyToOne, OneToMany, JoinColumn
} from 'typeorm';
import { User } from '../users/user.entity';
import { Institution } from '../institutions/institution.entity';
import { Verification } from '../verifications/verification.entity';

export enum CredentialType {
  DEGREE = 'degree',
  HND = 'hnd',
  OND = 'ond',
  WAEC = 'waec',
  NECO = 'neco',
  NABTEB = 'nabteb',
  PROFESSIONAL = 'professional',
  VOCATIONAL = 'vocational',
  BOOTCAMP = 'bootcamp',
  OTHER = 'other',
}

export enum CredentialStatus {
  PENDING = 'pending',
  UNDER_REVIEW = 'under_review',
  VERIFIED = 'verified',
  REJECTED = 'rejected',
  EXPIRED = 'expired',
}

@Entity('credentials')
export class Credential {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'enum', enum: CredentialType })
  type: CredentialType;

  @Column()
  title: string;

  @Column({ nullable: true })
  field_of_study: string;

  @Column({ nullable: true })
  grade: string;

  @Column({ type: 'date', nullable: true })
  issued_date: Date;

  @Column({ type: 'date', nullable: true })
  expiry_date: Date;

  @Column()
  document_url: string; // S3 key

  @Column({ nullable: true })
  certificate_number: string;

  @Column({ type: 'enum', enum: CredentialStatus, default: CredentialStatus.PENDING })
  status: CredentialStatus;

  @Column({ nullable: true })
  blockchain_tx_hash: string;

  @Column({ nullable: true })
  blockchain_credential_id: string;

  @Column({ unique: true, nullable: true })
  qr_code_id: string; // short UUID for QR URL

  @Column({ nullable: true })
  share_url: string;

  @Column({ type: 'decimal', precision: 5, scale: 2, nullable: true })
  fraud_score: number; // 0-100, higher = more suspicious

  @Column({ type: 'jsonb', nullable: true })
  fraud_flags: Record<string, any>;

  @Column({ default: true })
  is_public: boolean;

  @Column({ default: 0 })
  view_count: number;

  @ManyToOne(() => User, user => user.credentials)
  @JoinColumn({ name: 'graduate_id' })
  graduate: User;

  @Column()
  graduate_id: string;

  @ManyToOne(() => Institution, inst => inst.credentials, { nullable: true })
  @JoinColumn({ name: 'institution_id' })
  institution: Institution;

  @Column({ nullable: true })
  institution_id: string;

  @OneToMany(() => Verification, v => v.credential)
  verifications: Verification[];

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}
