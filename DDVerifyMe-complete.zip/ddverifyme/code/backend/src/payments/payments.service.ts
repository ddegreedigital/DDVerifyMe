import { Injectable, Logger, BadRequestException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import axios from 'axios';
import * as crypto from 'crypto';

export type PricingPlan = 'employer_starter' | 'employer_growth' | 'employer_enterprise'
  | 'institution_standard' | 'institution_premium'
  | 'graduate_pro' | 'graduate_career'
  | 'one_time_domestic' | 'one_time_international' | 'one_time_express';

const PRICING: Record<PricingPlan, { amount: number; currency: string; name: string }> = {
  employer_starter:       { amount: 1500000, currency: 'NGN', name: 'Employer Starter' },       // ₦15,000
  employer_growth:        { amount: 5000000, currency: 'NGN', name: 'Employer Growth' },         // ₦50,000
  employer_enterprise:    { amount: 15000000, currency: 'NGN', name: 'Employer Enterprise' },    // ₦150,000
  institution_standard:   { amount: 50000000, currency: 'NGN', name: 'Institution Standard' },  // ₦500,000/yr
  institution_premium:    { amount: 120000000, currency: 'NGN', name: 'Institution Premium' },  // ₦1.2M/yr
  graduate_pro:           { amount: 200000, currency: 'NGN', name: 'Graduate Pro' },             // ₦2,000
  graduate_career:        { amount: 500000, currency: 'NGN', name: 'Graduate Career' },          // ₦5,000
  one_time_domestic:      { amount: 300000, currency: 'NGN', name: 'Domestic Verification' },   // ₦3,000
  one_time_international: { amount: 800000, currency: 'NGN', name: 'International Verification' }, // ₦8,000
  one_time_express:       { amount: 1500000, currency: 'NGN', name: 'Express Verification' },   // ₦15,000
};

@Injectable()
export class PaymentsService {
  private readonly logger = new Logger(PaymentsService.name);
  private readonly paystackBase = 'https://api.paystack.co';

  constructor(private config: ConfigService) {}

  private get headers() {
    return {
      Authorization: `Bearer ${this.config.get('PAYSTACK_SECRET_KEY')}`,
      'Content-Type': 'application/json',
    };
  }

  async initializeTransaction(params: {
    email: string;
    plan: PricingPlan;
    userId: string;
    metadata?: Record<string, any>;
  }) {
    const pricing = PRICING[params.plan];
    if (!pricing) throw new BadRequestException('Invalid pricing plan');

    const reference = `ddv_${Date.now()}_${Math.random().toString(36).substring(7)}`;

    const { data } = await axios.post(
      `${this.paystackBase}/transaction/initialize`,
      {
        email: params.email,
        amount: pricing.amount, // in kobo
        currency: pricing.currency,
        reference,
        callback_url: `${this.config.get('APP_URL')}/payment/callback`,
        metadata: {
          user_id: params.userId,
          plan: params.plan,
          plan_name: pricing.name,
          ...params.metadata,
        },
      },
      { headers: this.headers },
    );

    return {
      authorization_url: data.data.authorization_url,
      reference: data.data.reference,
      access_code: data.data.access_code,
    };
  }

  async verifyTransaction(reference: string) {
    const { data } = await axios.get(
      `${this.paystackBase}/transaction/verify/${reference}`,
      { headers: this.headers },
    );

    return {
      success: data.data.status === 'success',
      amount: data.data.amount / 100, // Convert from kobo
      currency: data.data.currency,
      metadata: data.data.metadata,
      paid_at: data.data.paid_at,
    };
  }

  /**
   * Verify Paystack webhook signature
   */
  verifyWebhookSignature(rawBody: Buffer, signature: string): boolean {
    const hash = crypto
      .createHmac('sha512', this.config.get('PAYSTACK_SECRET_KEY'))
      .update(rawBody)
      .digest('hex');
    return hash === signature;
  }

  getPricingTable() {
    return Object.entries(PRICING).map(([key, value]) => ({
      plan: key,
      ...value,
      amount_formatted: `₦${(value.amount / 100).toLocaleString()}`,
    }));
  }
}
