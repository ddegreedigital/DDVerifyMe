import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { CredentialType } from '../credentials/credential.entity';
import Anthropic from '@anthropic-ai/sdk';

interface FraudAnalysisResult {
  score: number; // 0-100, higher = more suspicious
  flags: {
    anomalies: string[];
    risk_level: 'low' | 'medium' | 'high';
    reasoning: string;
    ocr_text_extracted: string;
  };
}

@Injectable()
export class AiService {
  private readonly logger = new Logger(AiService.name);
  private anthropic: Anthropic;

  constructor(private config: ConfigService) {
    this.anthropic = new Anthropic({
      apiKey: config.get('ANTHROPIC_API_KEY'),
    });
  }

  async analyzeDocument(
    fileBuffer: Buffer,
    credentialType: CredentialType,
  ): Promise<FraudAnalysisResult> {
    try {
      const base64 = fileBuffer.toString('base64');

      const response = await this.anthropic.messages.create({
        model: 'claude-opus-4-6',
        max_tokens: 1024,
        messages: [
          {
            role: 'user',
            content: [
              {
                type: 'image',
                source: { type: 'base64', media_type: 'image/jpeg', data: base64 },
              },
              {
                type: 'text',
                text: `You are a document fraud detection expert specializing in African educational certificates.

Analyze this ${credentialType} certificate image for fraud indicators.

Return ONLY valid JSON with this structure:
{
  "score": <0-100 integer, higher = more suspicious>,
  "risk_level": "<low|medium|high>",
  "anomalies": [<list of specific suspicious elements found, empty array if none>],
  "reasoning": "<brief explanation>",
  "ocr_text": "<key text extracted from document>"
}

Common fraud indicators:
- Pixelated or inconsistent fonts
- Misaligned text or logos
- Wrong institution letterhead or seal
- Implausible dates or graduation timelines
- Missing standard security features
- Poor print quality inconsistent with official documents
- Generic templates with wrong institution details`,
              },
            ],
          },
        ],
      });

      const text = response.content[0].type === 'text' ? response.content[0].text : '{}';
      const clean = text.replace(/```json|```/g, '').trim();
      const parsed = JSON.parse(clean);

      return {
        score: Math.min(100, Math.max(0, parsed.score || 0)),
        flags: {
          anomalies: parsed.anomalies || [],
          risk_level: parsed.risk_level || 'low',
          reasoning: parsed.reasoning || '',
          ocr_text_extracted: parsed.ocr_text || '',
        },
      };
    } catch (err) {
      this.logger.error('AI analysis failed:', err.message);
      // Return neutral score on failure — don't block the upload
      return {
        score: 0,
        flags: {
          anomalies: [],
          risk_level: 'low',
          reasoning: 'Analysis unavailable',
          ocr_text_extracted: '',
        },
      };
    }
  }

  async generateVerificationReport(credential: {
    title: string;
    type: string;
    graduateName: string;
    institutionName: string;
    issuedDate: string;
    fraudScore: number;
    fraudFlags: any;
    blockchainTxHash?: string;
    verifiedAt: string;
  }): Promise<string> {
    const response = await this.anthropic.messages.create({
      model: 'claude-opus-4-6',
      max_tokens: 800,
      messages: [
        {
          role: 'user',
          content: `Generate a professional credential verification report for an HR manager.

Credential details:
${JSON.stringify(credential, null, 2)}

Write a concise, professional 3-paragraph report covering:
1. Verification summary (what was verified, when, how)
2. Authenticity assessment (fraud score interpretation, blockchain status)
3. Recommendation for the hiring decision

Keep it factual, professional, and under 200 words.`,
        },
      ],
    });

    return response.content[0].type === 'text' ? response.content[0].text : '';
  }
}
