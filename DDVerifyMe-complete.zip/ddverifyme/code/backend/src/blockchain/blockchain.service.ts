import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ethers } from 'ethers';
import * as crypto from 'crypto';

// Minimal ABI for our credential registry contract
const CONTRACT_ABI = [
  'function anchorCredential(bytes32 credentialHash, string calldata metadata) external returns (uint256)',
  'function verifyCredential(bytes32 credentialHash) external view returns (bool exists, uint256 timestamp, address issuer)',
  'event CredentialAnchored(bytes32 indexed credentialHash, address indexed issuer, uint256 timestamp)',
];

interface AnchorInput {
  credentialId: string;
  graduateId: string;
  institutionId: string;
  title: string;
  issuedDate?: string;
}

interface AnchorResult {
  txHash: string;
  credentialId: string;
  credentialHash: string;
}

@Injectable()
export class BlockchainService {
  private readonly logger = new Logger(BlockchainService.name);
  private provider: ethers.JsonRpcProvider;
  private wallet: ethers.Wallet;
  private contract: ethers.Contract;

  constructor(private config: ConfigService) {
    const rpcUrl = config.get('POLYGON_RPC_URL') || 'https://polygon-rpc.com';
    const privateKey = config.get('BLOCKCHAIN_PRIVATE_KEY');
    const contractAddress = config.get('CONTRACT_ADDRESS');

    this.provider = new ethers.JsonRpcProvider(rpcUrl);

    if (privateKey) {
      this.wallet = new ethers.Wallet(privateKey, this.provider);
      if (contractAddress) {
        this.contract = new ethers.Contract(contractAddress, CONTRACT_ABI, this.wallet);
      }
    }
  }

  /**
   * Creates a deterministic hash of the credential for on-chain storage.
   * No PII is stored on-chain — only the hash.
   */
  private hashCredential(input: AnchorInput): string {
    const payload = JSON.stringify({
      credentialId: input.credentialId,
      graduateId: input.graduateId,
      institutionId: input.institutionId,
      title: input.title,
      issuedDate: input.issuedDate,
    });
    return '0x' + crypto.createHash('sha256').update(payload).digest('hex');
  }

  async anchorCredential(input: AnchorInput): Promise<AnchorResult> {
    if (!this.contract) {
      // Return mock result in development
      this.logger.warn('Blockchain not configured — returning mock anchor');
      return {
        txHash: '0x' + crypto.randomBytes(32).toString('hex'),
        credentialId: input.credentialId,
        credentialHash: this.hashCredential(input),
      };
    }

    const credentialHash = this.hashCredential(input);
    const metadata = JSON.stringify({
      type: 'DDVerifyMe/VerifiedCredential/v1',
      credentialId: input.credentialId,
      timestamp: new Date().toISOString(),
    });

    this.logger.log(`Anchoring credential ${input.credentialId} to Polygon...`);

    const tx = await this.contract.anchorCredential(credentialHash, metadata, {
      gasLimit: 200000,
    });
    await tx.wait(2); // Wait for 2 confirmations

    this.logger.log(`Anchored: ${tx.hash}`);

    return {
      txHash: tx.hash,
      credentialId: input.credentialId,
      credentialHash,
    };
  }

  async verifyOnChain(credentialHash: string): Promise<{
    exists: boolean;
    timestamp?: Date;
    issuer?: string;
  }> {
    if (!this.contract) {
      return { exists: false };
    }

    const [exists, timestamp, issuer] = await this.contract.verifyCredential(credentialHash);
    return {
      exists,
      timestamp: exists ? new Date(Number(timestamp) * 1000) : undefined,
      issuer: exists ? issuer : undefined,
    };
  }

  /**
   * Generate a W3C Verifiable Credential JSON-LD document
   */
  generateW3CCredential(credential: {
    id: string;
    graduateName: string;
    graduateDid?: string;
    title: string;
    type: string;
    institutionName: string;
    issuedDate: string;
    txHash: string;
  }) {
    return {
      '@context': [
        'https://www.w3.org/2018/credentials/v1',
        'https://ddverifyme.com/contexts/v1',
      ],
      id: `https://ddverifyme.com/credentials/${credential.id}`,
      type: ['VerifiableCredential', 'EducationalCredential'],
      issuer: {
        id: `https://ddverifyme.com/institutions/${credential.institutionName}`,
        name: credential.institutionName,
      },
      issuanceDate: credential.issuedDate,
      credentialSubject: {
        id: credential.graduateDid || `did:ddverify:${credential.id}`,
        name: credential.graduateName,
        hasCredential: {
          type: credential.type,
          name: credential.title,
          awardedBy: credential.institutionName,
          dateAwarded: credential.issuedDate,
        },
      },
      proof: {
        type: 'EthereumBlockchainProof2023',
        created: new Date().toISOString(),
        blockchainTxHash: credential.txHash,
        network: 'polygon-mainnet',
        verificationMethod: 'https://ddverifyme.com/verify',
      },
    };
  }
}
