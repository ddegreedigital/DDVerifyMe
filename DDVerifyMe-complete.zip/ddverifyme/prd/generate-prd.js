const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  HeadingLevel, AlignmentType, BorderStyle, WidthType, ShadingType,
  LevelFormat, Footer, Header, TabStopType, TabStopPosition,
  PageBreak
} = require('docx');
const fs = require('fs');

const BLUE = "1A56DB";
const DARK = "1E293B";
const LIGHT_BLUE = "EFF6FF";
const GRAY = "64748B";
const GREEN = "16A34A";
const ORANGE = "EA580C";
const border = { style: BorderStyle.SINGLE, size: 1, color: "DBEAFE" };
const borders = { top: border, bottom: border, left: border, right: border };
const noBorder = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const noBorders = { top: noBorder, bottom: noBorder, left: noBorder, right: noBorder };

function heading1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 120 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: BLUE, space: 6 } },
    children: [new TextRun({ text, bold: true, size: 32, color: BLUE, font: "Arial" })]
  });
}
function heading2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 240, after: 80 },
    children: [new TextRun({ text, bold: true, size: 26, color: DARK, font: "Arial" })]
  });
}
function heading3(text) {
  return new Paragraph({
    spacing: { before: 180, after: 60 },
    children: [new TextRun({ text, bold: true, size: 22, color: DARK, font: "Arial" })]
  });
}
function body(text, opts = {}) {
  return new Paragraph({
    spacing: { before: 60, after: 80 },
    children: [new TextRun({ text, size: 22, color: DARK, font: "Arial", ...opts })]
  });
}
function bullet(text, level = 0) {
  return new Paragraph({
    numbering: { reference: "bullets", level },
    spacing: { before: 40, after: 40 },
    children: [new TextRun({ text, size: 22, color: DARK, font: "Arial" })]
  });
}
function space(n = 1) {
  return Array(n).fill(new Paragraph({ children: [new TextRun("")] }));
}
function infoBox(label, text, color = LIGHT_BLUE) {
  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [9360],
    rows: [new TableRow({ children: [new TableCell({
      borders,
      width: { size: 9360, type: WidthType.DXA },
      shading: { fill: color, type: ShadingType.CLEAR },
      margins: { top: 120, bottom: 120, left: 160, right: 160 },
      children: [
        new Paragraph({ children: [new TextRun({ text: label, bold: true, size: 20, color: BLUE, font: "Arial" })] }),
        new Paragraph({ children: [new TextRun({ text, size: 20, color: DARK, font: "Arial" })] }),
      ]
    })]})],
  });
}
function twoColRow(cells, headerRow = false) {
  return new TableRow({
    tableHeader: headerRow,
    children: cells.map((c, i) => new TableCell({
      borders,
      width: { size: i === 0 ? 2340 : 7020, type: WidthType.DXA },
      shading: { fill: headerRow ? "DBEAFE" : (i === 0 ? "F8FAFC" : "FFFFFF"), type: ShadingType.CLEAR },
      margins: { top: 80, bottom: 80, left: 120, right: 120 },
      children: [new Paragraph({ children: [new TextRun({ text: c, bold: headerRow || i === 0, size: 20, color: headerRow ? BLUE : DARK, font: "Arial" })] })]
    }))
  });
}
function threeColRow(cells, headerRow = false) {
  return new TableRow({
    tableHeader: headerRow,
    children: cells.map((c, i) => new TableCell({
      borders,
      width: { size: [2400, 4080, 2880][i], type: WidthType.DXA },
      shading: { fill: headerRow ? "DBEAFE" : "FFFFFF", type: ShadingType.CLEAR },
      margins: { top: 80, bottom: 80, left: 120, right: 120 },
      children: [new Paragraph({ children: [new TextRun({ text: c, bold: headerRow, size: 20, color: headerRow ? BLUE : DARK, font: "Arial" })] })]
    }))
  });
}

const doc = new Document({
  numbering: {
    config: [{
      reference: "bullets",
      levels: [{
        level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 720, hanging: 360 } } }
      }, {
        level: 1, format: LevelFormat.BULLET, text: "◦", alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 1080, hanging: 360 } } }
      }]
    }]
  },
  styles: {
    default: { document: { run: { font: "Arial", size: 22 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 32, bold: true, font: "Arial", color: BLUE },
        paragraph: { spacing: { before: 360, after: 120 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 26, bold: true, font: "Arial", color: DARK },
        paragraph: { spacing: { before: 240, after: 80 }, outlineLevel: 1 } },
    ]
  },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 }
      }
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: BLUE, space: 4 } },
          children: [
            new TextRun({ text: "DDVerifyMe — Product Requirements Document", size: 18, color: GRAY, font: "Arial" }),
            new TextRun({ text: "    CONFIDENTIAL", size: 18, color: ORANGE, bold: true, font: "Arial" }),
          ]
        })]
      })
    },
    footers: {
      default: new Footer({
        children: [new Paragraph({
          border: { top: { style: BorderStyle.SINGLE, size: 2, color: "DBEAFE", space: 4 } },
          tabStops: [{ type: TabStopType.RIGHT, position: TabStopPosition.MAX }],
          children: [
            new TextRun({ text: "© 2025 DDVerifyMe. All rights reserved.", size: 16, color: GRAY, font: "Arial" }),
            new TextRun({ text: "\tPage ", size: 16, color: GRAY, font: "Arial" }),
            new TextRun({ text: "  DDVerifyMe Confidential", size: 16, color: GRAY, font: "Arial" })
          ]
        })]
      })
    },
    children: [
      // COVER
      new Paragraph({ spacing: { before: 1440 }, alignment: AlignmentType.CENTER, children: [new TextRun({ text: "DDVerifyMe", size: 72, bold: true, color: BLUE, font: "Arial" })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Africa's Credential Verification Platform", size: 32, color: GRAY, font: "Arial" })] }),
      ...space(2),
      new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Product Requirements Document (PRD)", size: 28, bold: true, color: DARK, font: "Arial" })] }),
      ...space(1),
      new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Version 1.0  |  May 2025  |  Confidential", size: 20, color: GRAY, font: "Arial" })] }),
      ...space(6),

      // 1. EXECUTIVE SUMMARY
      heading1("1. Executive Summary"),
      body("DDVerifyMe is a pan-African educational and professional credential verification platform built for the digital age. It solves the continent's certificate fraud crisis by connecting graduates, employers, and institutions on a single platform — powered by blockchain anchoring, AI fraud detection, and a mobile-first experience."),
      ...space(),
      infoBox("Mission Statement", "To make credential trust instant, portable, and fraud-proof across all 54 African nations — putting graduates in control of their own verified identities."),
      ...space(),
      body("The platform operates three distinct portals: a Graduate Credential Wallet, an Employer/HR Verification Portal, and an Institution Records Management system. Together, they create a self-reinforcing network effect that grows with every new user."),

      ...space(),
      // 2. PROBLEM STATEMENT
      heading1("2. Problem Statement"),
      heading2("2.1 The African Credential Fraud Crisis"),
      body("Africa's credential verification ecosystem is broken. The consequences are severe for all stakeholders:"),
      ...space(),
      new Table({
        width: { size: 9360, type: WidthType.DXA },
        columnWidths: [2340, 7020],
        rows: [
          twoColRow(["Stakeholder", "Pain Point"], true),
          twoColRow(["Graduates", "Lengthy, expensive verification delays cost them jobs and admissions opportunities. No portable credential standard exists."]),
          twoColRow(["Employers", "1 in 5 certificates presented in Nigeria is suspected fraudulent. Manual checks cost $30–80 and take 20+ days per candidate."]),
          twoColRow(["Institutions", "Inundated with manual verification requests via phone/email. No digital infrastructure to manage records at scale."]),
          twoColRow(["Government", "No unified national credential register. Inter-state and cross-border hiring is hamstrung by institutional fragmentation."]),
        ]
      }),
      ...space(),
      heading2("2.2 Market Gaps in Existing Solutions"),
      bullet("No platform covers all credential types (degrees, vocational, professional memberships, bootcamps)"),
      bullet("No candidate-owned, portable credential wallet exists in Africa"),
      bullet("No blockchain-anchored verification with global portability"),
      bullet("No API-first product for HR tech integrations"),
      bullet("No pan-African platform supporting francophone/lusophone markets"),
      bullet("Turnaround times average 7–20 days — unacceptable for modern hiring"),

      ...space(),
      // 3. PRODUCT VISION
      heading1("3. Product Vision & Goals"),
      heading2("3.1 Vision"),
      body("To be the infrastructure layer for credential trust in Africa — the equivalent of what SWIFT is for banking, but for academic and professional identities."),
      ...space(),
      heading2("3.2 Success Metrics (18 Months)"),
      new Table({
        width: { size: 9360, type: WidthType.DXA },
        columnWidths: [3120, 3120, 3120],
        rows: [
          threeColRow(["Metric", "Target", "Stretch"], true),
          threeColRow(["Institutions onboarded", "50", "150"]),
          threeColRow(["Employer accounts", "200", "500"]),
          threeColRow(["Graduate profiles", "10,000", "50,000"]),
          threeColRow(["Avg. verification time", "< 48 hours", "< 4 hours"]),
          threeColRow(["Countries active", "3", "8"]),
          threeColRow(["ARR", "₦18M", "₦60M"]),
        ]
      }),

      ...space(),
      // 4. USER PERSONAS
      heading1("4. User Personas"),
      heading2("4.1 Graduate — Amara, 24, Fresh Graduate"),
      body("Amara graduated from University of Lagos with a B.Sc. in Computer Science. She's applying to a fintech company in London and needs her degree verified quickly. She has no document management system and stores certificates in a WhatsApp chat."),
      bullet("Needs: Fast, cheap, portable verification she can share globally"),
      bullet("Pain: Previous employer took 6 weeks to verify her certificate manually"),
      bullet("Device: Android smartphone, intermittent data connection"),
      ...space(),
      heading2("4.2 Employer — Tunde, HR Manager at a Lagos Fintech"),
      body("Tunde manages hiring for a 200-person company. He processes 50+ applications a month and has been burned by two fraudulent degree certificates in the past year."),
      bullet("Needs: Fast, reliable, legally defensible verification with audit trail"),
      bullet("Pain: Current process involves emailing institutions and waiting weeks"),
      bullet("Device: Windows laptop, integrated with BambooHR"),
      ...space(),
      heading2("4.3 Institution Admin — Dr. Okafor, Registrar at a Nigerian University"),
      body("Dr. Okafor's office receives 300+ verification requests per month via phone, email, and walk-ins. Her team of 3 spends 40% of their time on verifications instead of student services."),
      bullet("Needs: Streamlined digital system to receive, process, and respond to verifications"),
      bullet("Pain: No digital record system; relies on paper ledgers and Excel sheets"),
      bullet("Device: Desktop computer, slow institutional internet"),

      ...space(),
      // 5. FEATURES
      heading1("5. Feature Requirements"),
      heading2("5.1 Graduate Credential Wallet"),
      ...["Upload credentials (PDF, image) with metadata tagging",
        "Request institution verification with one click",
        "Blockchain anchoring upon successful verification (Polygon/W3C VC)",
        "Shareable QR code and unique credential URL",
        "Privacy controls — choose what employers can see",
        "Mobile-first PWA with offline document access",
        "Support for all credential types: degrees, O-levels, HND, vocational, professional",
        "Credential expiry alerts for time-bound certifications",
      ].map(t => bullet(t)),

      ...space(),
      heading2("5.2 Employer / HR Portal"),
      ...["Verify credentials via QR scan, URL, or manual lookup",
        "AI fraud risk score per credential (0–100, with explanation)",
        "Batch verification via CSV upload",
        "REST API with full OpenAPI documentation",
        "Webhook support for ATS integrations (Workday, BambooHR, Jobberman)",
        "Verification history and audit trail with PDF report export",
        "Team accounts with role-based permissions",
        "Pay-per-use or subscription billing (Paystack/Flutterwave)",
      ].map(t => bullet(t)),

      ...space(),
      heading2("5.3 Institution Portal"),
      ...["Receive and respond to verification requests (approve/reject/query)",
        "Upload and manage digital graduate records",
        "Issue blockchain-anchored digital certificates natively",
        "Analytics dashboard: verification volume, by department, by employer",
        "API for direct student records system integration",
        "White-label certificate templates",
        "Bulk import of historical records via CSV/Excel",
      ].map(t => bullet(t)),

      ...space(),
      heading2("5.4 Admin / Operations Dashboard"),
      ...["Manage institutions, employers, graduates",
        "Fraud flagging and manual review queue",
        "Platform health metrics and uptime monitoring",
        "Revenue and billing management",
        "Content moderation for institution profiles",
      ].map(t => bullet(t)),

      ...space(),
      // 6. TECHNICAL ARCHITECTURE
      heading1("6. Technical Architecture"),
      heading2("6.1 System Overview"),
      body("DDVerifyMe is built as a microservices architecture deployed on AWS (af-south-1 region, Cape Town) for lowest-latency access across sub-Saharan Africa. All services communicate via REST APIs with an event-driven layer (SQS/SNS) for async processing."),
      ...space(),
      heading2("6.2 Stack Decisions"),
      new Table({
        width: { size: 9360, type: WidthType.DXA },
        columnWidths: [2340, 3600, 3420],
        rows: [
          new TableRow({ tableHeader: true, children: ["Layer","Technology","Rationale"].map((c,i) => new TableCell({
            borders, width: { size: [2340,3600,3420][i], type: WidthType.DXA },
            shading: { fill: "DBEAFE", type: ShadingType.CLEAR },
            margins: { top: 80, bottom: 80, left: 120, right: 120 },
            children: [new Paragraph({ children: [new TextRun({ text: c, bold: true, size: 20, color: BLUE, font: "Arial" })] })]
          })) }),
          ...([
            ["Frontend","Next.js 14 + React Native","SSR for SEO; single codebase mobile"],
            ["Backend","Node.js + NestJS","TypeScript, DI, modular, OpenAPI native"],
            ["Database","PostgreSQL + Redis","ACID compliance + caching layer"],
            ["Blockchain","Polygon + W3C VC","Low gas fees, EVM-compatible, global standard"],
            ["Storage","AWS S3","Encrypted document storage, CDN via CloudFront"],
            ["AI/ML","Python FastAPI sidecar","Fraud scoring, OCR, anomaly detection"],
            ["Payments","Paystack + Flutterwave","Nigeria + pan-Africa coverage"],
            ["Auth","Auth0 + JWT","SSO, MFA, institutional SAML support"],
            ["Infra","AWS ECS Fargate + RDS","Auto-scaling, managed database"],
          ]).map(([a,b,c]) => new TableRow({ children: [a,b,c].map((txt,i) => new TableCell({
            borders, width: { size: [2340,3600,3420][i], type: WidthType.DXA },
            shading: { fill: "FFFFFF", type: ShadingType.CLEAR },
            margins: { top: 80, bottom: 80, left: 120, right: 120 },
            children: [new Paragraph({ children: [new TextRun({ text: txt, size: 20, color: DARK, font: "Arial" })] })]
          })) }))
        ]
      }),

      ...space(),
      heading2("6.3 Security & Compliance"),
      bullet("All documents encrypted at rest (AES-256) and in transit (TLS 1.3)"),
      bullet("NDPR (Nigeria Data Protection Regulation) compliance from day one"),
      bullet("GDPR-ready architecture for diaspora and EU-adjacent users"),
      bullet("Blockchain anchors are hash-only — no PII stored on-chain"),
      bullet("SOC 2 Type II audit roadmap for enterprise customers"),
      bullet("Penetration testing before launch and quarterly thereafter"),

      ...space(),
      // 7. MVP SCOPE
      heading1("7. MVP Scope & Phasing"),
      ...space(),
      infoBox("MVP Definition", "The MVP is the minimum feature set that allows one complete verification loop: a graduate uploads a credential → an institution verifies it → an employer checks it. Everything else is post-launch."),
      ...space(),
      heading2("Phase 1 — MVP (Months 1–3)"),
      bullet("Graduate: upload, request verification, receive QR code"),
      bullet("Institution: receive request, approve/reject, digital signature"),
      bullet("Employer: verify via QR or URL, receive PDF report"),
      bullet("Payment: pay-per-verification via Paystack"),
      bullet("Admin: basic dashboard for ops team"),
      ...space(),
      heading2("Phase 2 — Growth (Months 4–6)"),
      bullet("Blockchain anchoring (Polygon mainnet)"),
      bullet("Employer subscription plans + REST API v1"),
      bullet("AI fraud scoring (rule-based first, ML second)"),
      bullet("Mobile PWA launch"),
      bullet("Institution bulk record import"),
      ...space(),
      heading2("Phase 3 — Scale (Months 7–12)"),
      bullet("React Native apps (iOS + Android)"),
      bullet("Ghana and Kenya institution partnerships"),
      bullet("Francophone Africa (French language support)"),
      bullet("ATS integrations (Workday, BambooHR)"),
      bullet("Professional body certifications (ICAN, NMA, NBA)"),
      bullet("API marketplace listing"),

      ...space(),
      // 8. REVENUE
      heading1("8. Revenue Model"),
      heading2("8.1 Pricing Tiers"),
      new Table({
        width: { size: 9360, type: WidthType.DXA },
        columnWidths: [2340, 2340, 2340, 2340],
        rows: [
          new TableRow({ tableHeader: true, children: ["Segment","Plan","Price","Includes"].map((c,i) => new TableCell({
            borders, width: { size: 2340, type: WidthType.DXA },
            shading: { fill: "DBEAFE", type: ShadingType.CLEAR },
            margins: { top: 80, bottom: 80, left: 120, right: 120 },
            children: [new Paragraph({ children: [new TextRun({ text: c, bold: true, size: 20, color: BLUE, font: "Arial" })] })]
          })) }),
          ...([
            ["Employers","Starter","₦15,000/mo","20 verifications, dashboard"],
            ["Employers","Growth","₦50,000/mo","100 verifications, API, fraud score"],
            ["Employers","Enterprise","₦150,000/mo","Unlimited, ATS integration, SLA"],
            ["Institutions","Basic","Free","Respond to verifications"],
            ["Institutions","Standard","₦500,000/yr","Records mgmt, analytics"],
            ["Institutions","Premium","₦1,200,000/yr","Digital cert issuance, API"],
            ["Graduates","Free","₦0","3 credentials, basic QR"],
            ["Graduates","Pro","₦2,000/mo","Unlimited, blockchain anchor"],
            ["One-time","Domestic","₦3,000/check","Single verification"],
            ["One-time","International","₦8,000/check","Diaspora/foreign employers"],
          ]).map(row => new TableRow({ children: row.map((txt,i) => new TableCell({
            borders, width: { size: 2340, type: WidthType.DXA },
            shading: { fill: "FFFFFF", type: ShadingType.CLEAR },
            margins: { top: 80, bottom: 80, left: 120, right: 120 },
            children: [new Paragraph({ children: [new TextRun({ text: txt, size: 20, color: DARK, font: "Arial" })] })]
          })) }))
        ]
      }),

      ...space(),
      // 9. GO-TO-MARKET
      heading1("9. Go-to-Market Summary"),
      heading2("Phase 1 — Nigeria Beachhead (Months 1–6)"),
      bullet("Target top 20 Nigerian universities with free institution accounts"),
      bullet("Partner with CIPM (Chartered Institute of Personnel Management of Nigeria)"),
      bullet("Integrate with Jobberman and MyJobMag as verification partner"),
      bullet("NYSC orientation camp activations for graduate sign-ups"),
      bullet("Goal: 5,000 graduates, 200 employers, 20 institutions"),
      ...space(),
      heading2("Phase 2 — West Africa Expansion (Months 7–12)"),
      bullet("Ghana: partner with University of Ghana, KNUST, GhanaHR"),
      bullet("Kenya: University of Nairobi, IHRM Kenya"),
      bullet("Diaspora channel: UK, Canada, UAE corridors"),
      bullet("Goal: 3 countries, 50,000 graduates, ₦80M ARR"),

      ...space(),
      // 10. RISKS
      heading1("10. Risks & Mitigations"),
      new Table({
        width: { size: 9360, type: WidthType.DXA },
        columnWidths: [3120, 2880, 3360],
        rows: [
          new TableRow({ tableHeader: true, children: ["Risk","Likelihood","Mitigation"].map((c,i) => new TableCell({
            borders, width: { size: [3120,2880,3360][i], type: WidthType.DXA },
            shading: { fill: "DBEAFE", type: ShadingType.CLEAR },
            margins: { top: 80, bottom: 80, left: 120, right: 120 },
            children: [new Paragraph({ children: [new TextRun({ text: c, bold: true, size: 20, color: BLUE, font: "Arial" })] })]
          })) }),
          ...([
            ["Institutions refuse to participate","Medium","Offer free tier; start with progressive private universities"],
            ["Certificate fraud during upload","High","AI fraud scoring; institution must confirm all verifications"],
            ["Slow institution response times","High","SLA commitments + escalation alerts; auto-expire after 14 days"],
            ["Competitor copies the model","Medium","Network effect moat; first-mover advantage with institutions"],
            ["Regulatory pushback on blockchain","Low","Hash-only on-chain; full NDPR compliance; legal advisory board"],
            ["Payment failure/fraud","Medium","Paystack fraud tools; manual review for high-value verifications"],
          ]).map(([a,b,c]) => new TableRow({ children: [a,b,c].map((txt,i) => new TableCell({
            borders, width: { size: [3120,2880,3360][i], type: WidthType.DXA },
            shading: { fill: "FFFFFF", type: ShadingType.CLEAR },
            margins: { top: 80, bottom: 80, left: 120, right: 120 },
            children: [new Paragraph({ children: [new TextRun({ text: txt, size: 20, color: DARK, font: "Arial" })] })]
          })) }))
        ]
      }),

      ...space(),
      // 11. APPENDIX
      heading1("11. Appendix — Glossary"),
      ...([
        ["W3C VC","W3C Verifiable Credentials — an open standard for digital credentials"],
        ["DID","Decentralized Identifier — a blockchain-based digital identity"],
        ["NDPR","Nigeria Data Protection Regulation"],
        ["ATS","Applicant Tracking System — HR software for managing candidates"],
        ["CIPM","Chartered Institute of Personnel Management of Nigeria"],
        ["Polygon","An EVM-compatible blockchain with low transaction fees"],
        ["PWA","Progressive Web App — a web app installable like a native app"],
      ]).flatMap(([term, def]) => [
        body(`${term}: `, { bold: true }),
        body(def),
      ]),
    ]
  }]
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync("/home/claude/ddverifyme/prd/DDVerifyMe-PRD.docx", buf);
  console.log("PRD generated successfully");
});
