# DDVerifyMe — Africa's Credential Verification Platform

> Blockchain-anchored, AI-powered credential verification for all 54 African nations.

---

## Architecture Overview

```
ddverifyme/
├── code/
│   ├── backend/          # NestJS API (TypeScript)
│   │   └── src/
│   │       ├── auth/           # JWT auth, roles, guards
│   │       ├── credentials/    # Core credential entity & service
│   │       ├── verifications/  # Verification workflow & controller
│   │       ├── institutions/   # Institution portal
│   │       ├── employers/      # Employer portal & billing
│   │       ├── blockchain/     # Polygon anchoring (W3C VC)
│   │       ├── ai/             # Claude-powered fraud detection
│   │       ├── payments/       # Paystack integration
│   │       ├── notifications/  # Email + push notifications
│   │       └── storage/        # AWS S3 document storage
│   │
│   └── frontend/         # Next.js 14 (TypeScript)
│       └── src/
│           ├── pages/
│           │   ├── graduate/   # Credential wallet dashboard
│           │   ├── employer/   # Verification & HR portal
│           │   ├── institution/# Record management portal
│           │   └── verify/     # Public QR verification page
│           ├── components/     # Shared UI components
│           ├── services/       # API client
│           └── types/          # TypeScript types
│
├── prd/
│   └── DDVerifyMe-PRD.docx     # Full Product Requirements Document
│
└── docker-compose.yml          # Local development environment
```

---

## Quick Start

### Prerequisites
- Node.js 20+
- Docker + Docker Compose
- An Anthropic API key (for AI fraud detection)
- Paystack account (for payments — use test keys locally)

### 1. Clone & Configure

```bash
git clone https://github.com/yourorg/ddverifyme.git
cd ddverifyme

# Copy and fill in environment variables
cp .env.example .env.local
```

Edit `.env.local`:
```env
ANTHROPIC_API_KEY=sk-ant-...
PAYSTACK_SECRET_KEY=sk_test_...
AWS_ACCESS_KEY_ID=...
AWS_SECRET_ACCESS_KEY=...
AWS_S3_BUCKET=ddverifyme-documents-dev

# Optional (blockchain — leave blank to use mock anchoring in dev)
POLYGON_RPC_URL=https://polygon-rpc.com
BLOCKCHAIN_PRIVATE_KEY=
CONTRACT_ADDRESS=
```

### 2. Start Development Environment

```bash
docker-compose up -d
```

This starts:
- PostgreSQL on `localhost:5432`
- Redis on `localhost:6379`
- NestJS API on `localhost:4000`
- Next.js frontend on `localhost:3000`

### 3. Run Migrations & Seed

```bash
cd code/backend
npm install
npm run migration:run
npm run seed:dev       # Creates test institutions, users, credentials
```

### 4. Open the App

| Portal | URL |
|--------|-----|
| Graduate dashboard | http://localhost:3000/graduate |
| Employer portal | http://localhost:3000/employer |
| Institution portal | http://localhost:3000/institution |
| Public verification | http://localhost:3000/verify/:qrId |
| API docs (Swagger) | http://localhost:4000/api/docs |

---

## Key API Endpoints

### Public (no auth)
```
GET  /api/v1/verify/:qrCodeId        # Public credential verification
GET  /api/v1/institutions            # List all institutions
```

### Graduate (auth required, role: graduate)
```
GET  /api/v1/graduate/credentials                        # List my credentials
POST /api/v1/graduate/credentials                        # Upload new credential
POST /api/v1/graduate/credentials/:id/request-verification
POST /api/v1/graduate/credentials/:id/toggle-visibility
```

### Employer (auth required, role: employer)
```
POST /api/v1/employer/verify                             # Verify a credential
POST /api/v1/employer/verify/batch                       # Batch CSV verification
GET  /api/v1/employer/verifications                      # Verification history
```

### Institution (auth required, role: institution)
```
GET  /api/v1/institution/verifications/pending           # Pending requests
POST /api/v1/institution/verifications/:id/respond       # Approve or reject
POST /api/v1/institution/records/import                  # Bulk record import
```

---

## Technology Stack

| Layer | Technology | Why |
|-------|-----------|-----|
| Frontend | Next.js 14 + React | SSR, SEO, fast on mobile data |
| Mobile | React Native | Single codebase iOS/Android |
| Backend | NestJS (Node.js) | TypeScript, modular, OpenAPI |
| Database | PostgreSQL + Redis | ACID + caching |
| Blockchain | Polygon + W3C VC | Low gas, global standard |
| AI | Claude (Anthropic) | Document OCR + fraud scoring |
| Storage | AWS S3 | Encrypted document storage |
| Payments | Paystack + Flutterwave | Nigeria + pan-Africa |
| Auth | JWT + Auth0 | MFA, SSO, institutional SAML |
| Deploy | AWS ECS Fargate | Auto-scaling, af-south-1 region |

---

## Blockchain Architecture

Credentials are anchored to Polygon mainnet as:
- A SHA-256 hash of credential metadata (no PII on-chain)
- A W3C Verifiable Credential JSON-LD document
- An Ethereum event log with timestamp and issuer address

The smart contract address and ABI are in `code/backend/src/blockchain/`.

---

## Fraud Detection

The AI service uses Claude to:
1. OCR the uploaded certificate image
2. Check for visual anomalies (fonts, seals, alignment)
3. Compare against known institution formats
4. Return a 0–100 risk score with specific flags

Credentials with score > 65 are flagged for manual review.

---

## Contributing

1. Feature branches off `main`
2. All PRs require passing tests + type-check
3. API changes require Swagger doc updates
4. Run `npm run lint && npm run test` before pushing

---

## Roadmap

- [x] MVP: Graduate upload → Institution verify → Employer check
- [ ] Blockchain anchoring (Polygon mainnet)
- [ ] React Native mobile apps
- [ ] Ghana + Kenya expansion
- [ ] French language support
- [ ] ATS integrations (Workday, BambooHR)
- [ ] Professional body certifications (ICAN, NMA, NBA)

---

*Built with ❤️ for Africa — DDVerifyMe 2025*
